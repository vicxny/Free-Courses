//Make an api request using async await
